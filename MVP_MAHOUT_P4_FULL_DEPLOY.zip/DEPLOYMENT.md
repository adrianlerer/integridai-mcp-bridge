# DEPLOYMENT.md – MAHOUT pAIr MVP (CATALINA P4-Engine)

## COMPONENTES DEL SISTEMA

| Componente | Tecnología | Función Principal |
|------------|-------------|-------------------|
| Backend | Python + FastAPI + Docker | Evaluación metacognitiva, EVC, detección de alucinaciones |
| Frontend | React + TypeScript + Vite | Interfaz para consultas, confianza y trazabilidad |
| DB | PostgreSQL | Persistencia de datos, métricas y feedback |
| Cache | Redis | Almacenamiento en tiempo real |
| Infraestructura | Docker Compose | Orquestación del entorno completo |

## REQUISITOS PREVIOS

- Docker y Docker Compose instalados
- Node.js (≥ 18.x) y npm (para frontend local)
- Git (opcional)

## PASO A PASO

### 1. Backend

Descomprimir `p4_anti_hallucination_backend_v10_algorithms.zip`

```bash
docker-compose up --build
```

Acceder a: `http://localhost:8000/health` → `{"status": "ok"}`

### 2. Frontend

Descomprimir `p4_frontend_react_v1.zip`

```bash
cd p4_frontend_react
npm install
npm run dev
```

Acceder a: `http://localhost:5173`

### 3. Verificación

- Puntaje de confianza visible
- Delay metacognitivo 200–800ms
- Feedback habilitado
- `/metrics` funcional

## OPCIONES PRODUCCIÓN

| Componente | Plataforma sugerida |
|------------|---------------------|
| Backend | Render, Railway |
| Frontend | Vercel, Netlify |
| DB | Supabase, RDS |
| Redis | Upstash, Redis Cloud |

## SEGURIDAD

- JWT recomendado
- TLS vía proxy
- Logs y trazabilidad disponibles
